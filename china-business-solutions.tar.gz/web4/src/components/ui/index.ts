// Barrel file for UI components
export { default as WavyBackground } from './wavy-background';
export { default as AnimatedCounter } from './AnimatedCounter';
export { default as HoverEffect } from './hover-effect';
export { default as Pin } from './3d-pin';
