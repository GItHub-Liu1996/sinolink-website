// Barrel file for insights page components
export { default as ArticleCard } from './ArticleCard';
export { default as Pagination } from './Pagination';
